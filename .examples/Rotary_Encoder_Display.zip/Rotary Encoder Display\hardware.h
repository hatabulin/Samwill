/************************************************************************
	hardware.h

    Rotary Encoder with display demonstration
    Copyright (C) 2010 Simon Inns

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Email: simon.inns@gmail.com

************************************************************************/

#ifndef _HARDWARE_H_
#define _HARDWARE_H_

// Fosc frequency (48 Mhz)
#define _XTAL_FREQ 48000000

// Hardware mapping definitions:

// Serial chip select lines
#define CS_LED	RB0
#define OE_LED	RB2

// Rotary encoder
#define RE_A 	RB4
#define RE_B	RB5

// Switch
#define SWITCH0	RB3

// Other useful definitions
#define OFF		0
#define ON		1
#define FALSE	0
#define TRUE	1

// The following setting sets the speed of the timer0
// interrupt
#define TMR0_SPEED 0x00

// Structure for game hardware state mapping:
struct lightState {
	unsigned char state;
	int brightness;
	int dimSpeed;
};

// Overall hardware state
struct hardwareState {
	struct lightState light[16];

	// Internal counters
	unsigned char pwmCounter;
	int dimCounter;
	
	// Rotary Encoder position
	int encoderPosition;
	unsigned char encoderState;
	unsigned char encoderPreviousState;
	int encoderDirection;
	
	// Push button
	unsigned char buttonState;
	unsigned char buttonDebounce;

} hardware;

// Function prototypes
void initialise(void);

#endif