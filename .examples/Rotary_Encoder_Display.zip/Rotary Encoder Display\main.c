/************************************************************************
	main.c

    Rotary Encoder with display demonstration
    Copyright (C) 2010 Simon Inns

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Email: simon.inns@gmail.com

************************************************************************/

// Global includes
#include <htc.h>

// Local includes
#include "hardware.h"

// PIC 18F2550 fuse configuration:
// Config word 1 (Oscillator configuration)
// 20Mhz crystal input scaled to 48Mhz and configured for USB operation
// from Table 2-3 page 30 of the datasheet
__CONFIG(1, USBPLL & IESODIS & FCMDIS & HSPLL & CPUDIV1 & PLLDIV5);
// Config word 2
__CONFIG(2, VREGEN & PWRTDIS & BORDIS & WDTDIS);
// Config word 3
__CONFIG(3, PBDIGITAL & LPT1DIS & MCLREN);
// Config word 4
__CONFIG(4, XINSTDIS & STVRDIS & LVPDIS & ICPORTDIS & DEBUGDIS);
// Config word 5, 6 and 7 (protection configuration)
__CONFIG(5, UNPROTECT);
__CONFIG(6, UNPROTECT);
__CONFIG(7, UNPROTECT);

// Write 16 bits to the A6276 controller
void SPIwrite(unsigned char byte1, unsigned char byte2)
{
	// Disable latching
	CS_LED = 0;

	// Write the low byte
	SSPIF = 0;
	SSPBUF = byte1;
	while(!SSPIF); // Wait for transmit to complete

	// Write the high byte
	SSPIF = 0;
	SSPBUF = byte2;
	while(!SSPIF); // Wait for transmit to complete

	// Enable latching
	CS_LED = 1;
}

// High priority interrupt procedure
void interrupt hpHandler(void)
{
	// Is this a interrupt on change for PORTB?
	if (RBIF)
	{
		// Rotary encoder -------------------------------------------------------------------------
		hardware.encoderState = RB4 | RB5 << 1;
		if(hardware.encoderPreviousState != 0xFF) // Check for first time check
		{
			if(hardware.encoderPreviousState == 0b00 && hardware.encoderState == 0b01) 
			{
				// Going counter-clockwise
				hardware.encoderDirection = -1;
				hardware.encoderPosition--;
			}
 
			else if(hardware.encoderPreviousState == 0b01 && hardware.encoderState == 0b00) 
			{		
				// Going clockwise
				hardware.encoderDirection = 1;
				hardware.encoderPosition++;
			}
		}
		// Save the current state
		hardware.encoderPreviousState = hardware.encoderState;
		
		// Our encoder has 24 ticks per rotation
		if (hardware.encoderPosition > 23) hardware.encoderPosition = 0;
		if (hardware.encoderPosition < 0) hardware.encoderPosition = 23;		
		
		RBIF = 0;			// Clear the portB interrupt flag
	}
}	

// Low priority interrupt procedure
void interrupt low_priority lpHandler(void)
{
	unsigned char hByte = 0x00;
	unsigned char lByte = 0x00;
	unsigned char light;	

	// Is this timer0 interrupting?
	if (TMR0IF)
	{
		// Write the state of the lights **********************************************************
		for (light = 0; light < 16; light++)
		{
			if ((hardware.light[light].brightness == 100) ||
				(hardware.light[light].brightness != 0 && hardware.pwmCounter < hardware.light[light].brightness))
			{
				int sixteenBits = 1 << light;
				hByte |= sixteenBits >> 8;
				lByte |= sixteenBits & 0x00FF;
			}
		
			// If light is OFF and brightness > 0 then fade the light at dimSpeed
			if ((hardware.light[light].state == OFF) && (hardware.light[light].brightness > 0))
			{
				if (hardware.dimCounter == 0)
				{
					hardware.light[light].brightness -= hardware.light[light].dimSpeed;
					if (hardware.light[light].brightness < 0) hardware.light[light].brightness = 0;
				}
			}
		}

		// Write the state of the LEDs to the serial LED controller
		SPIwrite(hByte, lByte);

		// Increment the PWM counter
		hardware.pwmCounter++;
		if (hardware.pwmCounter == 100) hardware.pwmCounter = 0;

		// Increment the dimming counter
		hardware.dimCounter++;
		if (hardware.dimCounter == 100) hardware.dimCounter = 0;

		TMR0L = TMR0_SPEED;	// Reset the timer0 counter
		TMR0IF = 0;			// Clear the timer0 interrupt flag
	}
}

void lightOn(unsigned char light, unsigned char dimSpeed)
{
	hardware.light[light].dimSpeed = dimSpeed;
	hardware.light[light].brightness = 100;
	hardware.light[light].state = ON;
}

// This routine is for controlling a single LED
void lightOff(unsigned char light)
{
	hardware.light[light].state = OFF;
}

// Main function
void main(void)
{
	// Turn off analogue ports
	ADCON1 = 0x0F;

	// Configure ports as inputs (1) or outputs(0)
	TRISA = 0b00000000;
	TRISB = 0b00111000; // RB4 and 5 are A and B from the encoder, RB3 is a switch
	TRISC = 0b00000000; 

	// Clear all ports
	PORTA = 0b00000000;
	PORTB = 0b00000000;
	PORTC = 0b00000000;
	
 	// Enable portB weak pull-ups
	RBPU = 0;

	// Set up SPI
	SSPSTAT = 0b11000000;	// SPI Master
							// Tx occurs on idle to active transition

	SSPCON1 = 0b00100000;	// Serial port enabled
							// Speed is Fosc/4

	// Initialise the state model
	initialise();

	// Enable interrupts with priority
	IPEN = 1;

	// Timer0 is used to generate an interrupt which reads the
	// state of the buttons and writes the state of the lights
	// in accordance to the state model.  Timer0 causes a low
	// priority interrupt so as not to disturb the higher
	// priority interrupt which is used to generate sound.
	//
	// The timer0 interrupt is also used as a delay counter
	// by the delay routines.
	TMR0IP = 0;			// Set timer0 interrupt to low priority
	TMR0IF = 0;			// Clear the timer0 interrupt flag
	TMR0L = TMR0_SPEED;	// Reset the timer0 counter
	T0CON = 0b11000000; // Timer0 on, 8-bit and 1:2 prescaler
	TMR0IE = 1;			// Enable the timer0 interrupt
	
	// Enable interrupt on state change for RB4 and RB5 (the encoder inputs)
	RBIP = 1;	// PORT B interrupts high-priority
	RBIF = 0;	// Clear the portB interrupt flag
	RBIE = 1;	// Enable portB interrupt-on-change
	
	// Enable interrupts
	GIEH = 1;			// Global enable all high priority interrupts
	GIEL = 1;			// Global enable all low priority interrupts

	// Enable the LED output
	OE_LED = 0;
	
	// Power on greeting (rotates the lights)
	for (int spins = 0; spins < 3; spins++)
	{
		for (int counter = 0; counter < 16; counter++)
		{
			lightOn(counter, 4);
			for (int delay = 0; delay < 400; delay++) __delay_us(100);
			lightOff(counter);
		}
	}
	lightOn(0, 4);
	for (int delay = 0; delay < 400; delay++) __delay_us(100);
	lightOff(0);

	unsigned char displayMode = 0;
	unsigned char previousPosition = 0;
	int previousLedNumber = 1;
	unsigned char currentButtonState = 0;
	unsigned char previousButtonState = 0;
	int togglePosition = 1;
	
	unsigned char initDisplayFlag = 1;
	
	int volumeControl = 0;

	// Main loop
	while(1)
	{
		// Read the position into a local variable in case it changes whilst we are updating
		int newPosition = hardware.encoderPosition;
		int newDirection = hardware.encoderDirection;
		
		// Display mode 0 is a 360 degree position feedback
		if (displayMode == 0)
		{						
			// Work out which led should be on
			float ledNumberFloat = (float)newPosition / 1.5;
			int currentLedNumber = (int)ledNumberFloat;
			
			if ((currentLedNumber != previousLedNumber) || initDisplayFlag == 1)
			{
				lightOff(previousLedNumber);
				previousLedNumber = currentLedNumber;
				lightOn(currentLedNumber, 4);
				
				initDisplayFlag = 0;
			}	
		}
		
		// Display mode 1 is a volume control type feedback
		if (displayMode == 1)
		{
			if (initDisplayFlag == 1)
			{
				volumeControl = 0;
				lightOn(6, 20);
				initDisplayFlag = 0;
				newDirection = 0;
			}	
			
			// Has the encoder moved?
			if (newPosition != previousPosition)
			{
				if (newDirection == -1)
				{
					volumeControl++;
					if (volumeControl > 13) volumeControl = 13;
				}
				else
				{
					volumeControl--;
					if (volumeControl < 0) volumeControl = 0;
				}
				
				// Update the display
				if (volumeControl >= 0) lightOn(6, 20); 	else lightOff(6);
				if (volumeControl >= 1) lightOn(5, 20); 	else lightOff(5);
				if (volumeControl >= 2)	lightOn(4, 20); 	else lightOff(4);
				if (volumeControl >= 3)	lightOn(3, 20); 	else lightOff(3);
				if (volumeControl >= 4)	lightOn(2, 20); 	else lightOff(2);
				if (volumeControl >= 5)	lightOn(1, 20); 	else lightOff(1);
				if (volumeControl >= 6)	lightOn(0, 20); 	else lightOff(0);
				if (volumeControl >= 7)	lightOn(15, 20); 	else lightOff(15);
				if (volumeControl >= 8)	lightOn(14, 20); 	else lightOff(14);
				if (volumeControl >= 9)	lightOn(13, 20); 	else lightOff(13);
				if (volumeControl >= 10) lightOn(12, 20); 	else lightOff(12);
				if (volumeControl >= 11) lightOn(11, 20); 	else lightOff(11);
				if (volumeControl >= 12) lightOn(10, 20); 	else lightOff(10);
			}
		}	
		
		// Display mode 2 is a 3 position toggle switch feedback
		if (displayMode == 2)
		{
			if (initDisplayFlag == 1)
			{
				togglePosition = 4;
				initDisplayFlag = 0;
				newDirection = 0;
				lightOn(1, 8); lightOn(0, 8); lightOn(15, 8);
			}
			
			// Has the encoder moved?
			if (newPosition != previousPosition)
			{
				if (newDirection == -1)
				{
					togglePosition++;
					if (togglePosition > 8) togglePosition = 8;
				}
				else
				{
					togglePosition--;
					if (togglePosition < 0) togglePosition = 0;
				}
				
				// Update the display
				if (togglePosition >= 0 && togglePosition < 3)
				{
					lightOn(2, 8); lightOn(3, 8); lightOn(4, 8);
				}
				else
				{
					lightOff(2); lightOff(3); lightOff(4);
				}
				
				if (togglePosition >= 3 && togglePosition < 6)
				{
					lightOn(1, 8); lightOn(0, 8); lightOn(15, 8);
				}
				else
				{
					lightOff(1); lightOff(0); lightOff(15);
				}
				
				if (togglePosition >= 6 && togglePosition < 9)
				{
					lightOn(14, 8); lightOn(13, 8); lightOn(12, 8);
				}
				else
				{
					lightOff(14); lightOff(13); lightOff(12);
				}
					
			}
		}		
		
		// Push Button debounce
		if (hardware.buttonState != SWITCH0)
		{
			if (hardware.buttonDebounce > 20)
			{
				hardware.buttonState = SWITCH0;
				hardware.buttonDebounce = 0;
			}
			else hardware.buttonDebounce++;
		}
		else hardware.buttonDebounce = 0;		
		
		// Process the push button
		currentButtonState = hardware.buttonState;
		if (currentButtonState == 0 && previousButtonState == 1)
		{
			// Button pressed, change the display mode
			displayMode++;
			if (displayMode > 2) displayMode = 0;
			
			// Reset the encoder position
			hardware.encoderPosition = 0;
			
			// Set the initialise display flag
			initDisplayFlag = 1;
			
			// Clear the display
			for (int counter = 0; counter < 16; counter++)
				lightOff(counter);
		}
		
		previousButtonState = currentButtonState;	
		previousPosition = newPosition;

	}
}		