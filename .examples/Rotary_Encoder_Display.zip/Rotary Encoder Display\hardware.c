/************************************************************************
	hardware.c

    Simon18F - An MB Electronics Simon clone based on the PIC18F2550
    Copyright (C) 2009 Simon Inns

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Email: simon.inns@gmail.com

************************************************************************/

#include <htc.h>
#include "hardware.h"

// Initialise the hardware state
void initialise(void)
{
	unsigned char loop;
	
	for (loop = 0; loop < 16; loop++)
	{
		hardware.light[loop].state = OFF;
		hardware.light[loop].brightness = 0;
		hardware.light[loop].dimSpeed = 100;
	}
	
	// This counter is used by the PWM light controls, it runs from 
	// 0 to 100 and is used as a comparison to the brightness setting
	// to determine if the light should be on or off for the current
	// interrupt call.
	hardware.pwmCounter = 0;

	// This counter is used to slow down the dimming (since the 
	// brightness is only 0 to 100 even dimming 1 unit per
	// interrupt would be too fast to see.  This counter ensures
	// dimming is only performed every few hundred calls to the 
	// interrupt.
	hardware.dimCounter = 0;
	
	// Rotatary encoder
	hardware.encoderPosition = 0;
	hardware.encoderState = 0;
	hardware.encoderPreviousState = 0xFF;
	hardware.encoderDirection = 0;
	
	// Push button
	hardware.buttonState = 0;
	hardware.buttonDebounce = 0;
}