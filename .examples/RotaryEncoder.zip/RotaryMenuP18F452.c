//***************************************************************************
#include "Delay.h"
#include "sLCD.h"
// RotaryMenuP18F452.c
// This Demo is written for the EasyPIC5 Controller Board and 2 Bit
// LCD on PORTA.   Written for 4X20 Character LCD.  Program
// can be easily adapted for 2X16 LCD.
// Menus are selected using 2-bit Rotary Encoder.
// Once a Menu is selected,  Display Encoder Value,  Press EncBut to
// return to Main Menu.  Encoder Values are saved in array.
// Encoder on PORTE, Bits F0 and F1.
// Program runs @ 20Mhz with 20Mhz Crystal
//
// Modified by
// RC Irace
// 1.30.2010
//***************************************************************************
//***************************************************************************
//Variable Declarations
//***************************************************************************
//                          1234567890123456
const char Message1[9]  = "Select 1";
const char Message2[9]  = "Select 2";
const char Message3[9]  = "Select 3";
const char Message4[9]  = "Select 4";
const char Message5[9]  = "Menu 1  ";
const char Message6[9]  = "Menu 2  ";
const char Message7[9]  = "Menu 3  ";
const char Message8[9]  = "Menu 4  ";
const char Message9[9]  = "Count = ";
const char Message19[17] = "Rotary Enc Menu ";
const char Message20[17] = "by RCI PIC18F452";
const char Message99[17] = "                ";
unsigned char temp, counter;
unsigned char old[3], new[3], count[5], cursorpos, cursortemp;
#define EncBut PORTE.F2
char txt[4];
//****************************************************************************
void Interrupt()
{
if (INTCON.F2 == 1)
   {

if ((PORTE & 0b00000010) ^ old[0] != 0)
   new[0] = PORTE & 0b00000010;
   if (new[0] > old[0])
      if ((PORTE & 0b00000001) == 1)
         {
         ++count[0];
         }
      else
         {
         --count[0];
         }
    old[0] = new[0];

    }
    INTCON.F2 = 0;       // clears TMR0 flag
}//end ISR
//***************************************************************************
void main()
{
unsigned char i, j, k, n, z;
unsigned char m, h, cleararrow;
          //  76543210
	ADCON1 =  0b00000100;
	PORTA =   0b00000000;       //  Start with Everything Low
	PORTB =   0b00000000;  			//  Start with Everything Low
	PORTC =   0b00000000;				//  Start with Everything Low
	PORTD =   0b00000000;				//  Start with Everything Low
	PORTE =   0b00000000;
	TRISA =   0b00001111;       //  First 4 of "A" are Inputs
	TRISB =   0b00000000;				//  All Outputs
	TRISC =   0b10111111;
	TRISD =   0b11111111;				//  All Inputs
	TRISE =   0b00000111;
	T0CON =   0b11000000; // Assign prescaler to TMR0   1 : 32
  INTCON =  0b10100000; // GIE PEIE TMR0IE INT0IE RBIE(1) TMR0IF(2) INT0IF RBIF
  INTCON.TMR0IE = 1;
  INTCON.TMR0IF = 0;
	n = 0;
	h = 1;
  m = 128;
  cleararrow = 128;
  count[0] = 1;
//***************************************************************************
// Initialize Encoder Count
//***************************************************************************
  for (i = 1; i < 5; i++)
      {
      count[i] = 0;
    	}
//***************************************************************************
// Initialize Serial LCD Display
//***************************************************************************
  Init_sDisplay();
	sResetLCD();					  //  Call Reset LCD
	Delay2000ms();
start:
//***************************************************************************
	sLCD_Out(sLCD_FIRST_ROW, 1, Message19);		   //  Displays Message on Row 1
	sLCD_Out(sLCD_SECOND_ROW, 1, Message20);		 //  Displays Message on Row 2
	Delay2000ms();
	sResetLCD();
	Delay120ms();
//***************************************************************************
//***************************************************************************
while (1 == 1)
	{
//	  sResetLCD();
//  Basic Menu Listing Here**************************************************
  	    sLCD_Out(sLCD_FIRST_ROW, 1, Message1); //  Displays Message on Row 1
		    sLCD_Out(sLCD_SECOND_ROW, 1, Message2);//  Displays Message on Row 2
  	    sLCD_Out(sLCD_THIRD_ROW, 1, Message3); //  Displays Message on Row 3
		    sLCD_Out(sLCD_FOURTH_ROW, 1, Message4);//  Displays Message on Row 4

    while (EncBut == 1)
        {
        while (EncBut == 0)
          {
          }
//  Menu Select Routine**********************************************
    		cursorpos = count[0];                 // Get Encoder value
        if (cursorpos >= 4) cursorpos = 4;
				if (cursorpos < 2) cursorpos = 1;
			  if (cursorpos == 1) m = sLCD_FIRST_ROW;
        if (cursorpos == 2) m = sLCD_SECOND_ROW;
        if (cursorpos == 3) m = sLCD_THIRD_ROW;
        if (cursorpos == 4) m = sLCD_FOURTH_ROW;
        if (cleararrow == m)                  // If Encoder Not Changed
           {
           sLCD_Chr(m, 11, 127);              // Display "Arrow"
           goto loop;
           }
//  Basic Menu Listing Here******************************************
        sResetLCD();
  	    sLCD_Out(sLCD_FIRST_ROW, 1, Message1); //  Displays Message on Row 1
		    sLCD_Out(sLCD_SECOND_ROW, 1, Message2);//  Displays Message on Row 2
  	    sLCD_Out(sLCD_THIRD_ROW, 1, Message3); //  Displays Message on Row 3
		    sLCD_Out(sLCD_FOURTH_ROW, 1, Message4);//  Displays Message on Row 4
        sLCD_Chr(m, 11, 127);                  //  Display "Arrow"
        cleararrow = m;
loop:
        Delay120ms();
        cursortemp = cursorpos;
        } // End While
        cursortemp = cursorpos;
//  Menu Select Routine******************************************************

        Delay120ms();
        Delay120ms();
        if (cursorpos == 1)
            {
            n = 1;
            count[0] = count[n];
            }
        if (cursorpos == 2)
            {
            n = 2;
            count[0] = count[n];
            }
        if (cursorpos == 3)
            {
            n = 3;
            count[0] = count[n];
            }
        if (cursorpos == 4)
            {
            n = 4;
            count[0] = count[n];
            }
        sResetLCD();

switch(n)
		{
//***************************************************************************
		case 1:	  // Menu 1

			sLCD_Out(sLCD_FIRST_ROW, 1, Message5);     // Menu 1
			while (EncBut == 1)     // Press EncBut to Exit Loop
        {
        // Insert Program Instructions here
        z = count[0];
			  count[n] = z;
			  sLCD_Out(sLCD_SECOND_ROW, 1, Message9);    // Count =
			  sLCDtoBCD(z, 3);
        }
      while (EncBut == 0)
          {
          }
      count[0] = cursortemp;
      sResetLCD();
      Delay120ms();
      n = 0;


		break;
//**************************************************************************
    case 2:	  // Menu 2

			sLCD_Out(sLCD_FIRST_ROW, 1, Message6);
			while (EncBut == 1)     // Press EncBut to Exit Loop
        {
        // Insert Program Instructions here
        z = count[0];
			  count[n] = z;
			  sLCD_Out(sLCD_SECOND_ROW, 1, Message9);
			  sLCDtoBCD(z, 3);
        }
      while (EncBut == 0)
          {
          }
      count[0] = cursortemp;
      sResetLCD();
      Delay120ms();
      n = 0;;

    break;
//**************************************************************************
		case 3: // Menu 3

			sLCD_Out(sLCD_FIRST_ROW, 1, Message7);
			while (EncBut == 1)     // Press EncBut to Exit Loop
        {
        // Insert Program Instructions here
        z = count[0];
			  count[n] = z;
			  sLCD_Out(sLCD_SECOND_ROW, 1, Message9);
			  sLCDtoBCD(z, 3);
        }
      while (EncBut == 0)
          {
          }
      count[0] = cursortemp;
      sResetLCD();
      Delay120ms();
      n = 0;

		break;
//**************************************************************************
		case 4: //  Menu 4

			sLCD_Out(sLCD_FIRST_ROW, 1, Message8);
			while (EncBut == 1)     // Press EncBut to Exit Loop
        {
        // Insert Program Instructions here
        z = count[0];
			  count[n] = z;
			  sLCD_Out(sLCD_SECOND_ROW, 1, Message9);
			  sLCDtoBCD(z, 3);
        }
      while (EncBut == 0)
          {
          }
      count[0] = cursortemp;
      sResetLCD();
      Delay120ms();
      n = 0;

    break;
//***************************************************************************

		default:
         z = 0;

        } // End Switch
	} //  End While
}  //  End Main
//***************************************************************************
//***************************************************************************

