//****************************************************************************
char output[10] = "%11111111";
char str[10];
char outputl[18] = "%1111111111111111";
char strl[18];
//****************************************************************************
void Byte2Binary(char row, char col, unsigned char byte_in, char *output)
{
unsigned char pos, k;
char output[10] = "%11111111";
  pos = 1;
  if (row == 1)
     row = 128;
	if (row == 2)
     row = 192;
	if (row == 3)
     row = 148;
	if (row == 4)
     row = 212;
  while (pos < 9)
    {
    if ((byte_in & 0x80) == 0)
       {
       output[pos] = 48;
       }
    byte_in = byte_in << 1;
    ++pos;
    }
    sLCD_Cmd(row + (col - 1));
    for (k = 0; k < 9; k++)
       {
		   sLCD_Chr_Cp(output[k]);
		   }
		    for (k = 10; k < 21; k++)
       {
		   sLCD_Chr_Cp(' ');
		   }
}
//****************************************************************************
void Word2Binary(char row, char col, unsigned int word_in, int *outputl)
{
unsigned char pos, k;
char outputl[18] = "%1111111111111111";
  pos = 1;
  if (row == 1)
     row = 128;
	if (row == 2)
     row = 192;
	if (row == 3)
     row = 148;
	if (row == 4)
     row = 212;
  while (pos < 17)
    {
    if ((word_in & 0x8000) == 0)
       {
       outputl[pos] = 48;
       }
    word_in = word_in << 1;
    ++pos;
    }
    sLCD_Cmd(row + (col - 1));
    for (k = 0; k < 17; k++)
       {
		   sLCD_Chr_Cp(outputl[k]);
		   }
}
//****************************************************************************