//**************************************************************************
//**************************************************************************
//	sLCD.h Include File
//	Serial 2 Data Line 4 X 20 LCD functions,  can be used with 2 Line LCD
//  Added Delay Subroutines to decrease memory usage
//  Replaced IF statements for ROW values with Constants
//  Decreased Nybble delay time from 150us to 5us
//  by RCI
//
//**************************************************************************
//**************************************************************************
#define Clk  PORTA.F4       //  Define the LCD Serial Pins
#define Data PORTA.F5

//**************************************************************************
//  sLCD_Consts.h
//  Cursor Move Commands for sLCD
const sLCD_FIRST_ROW         = 128;
const sLCD_SECOND_ROW        = 192;
const sLCD_THIRD_ROW         = 148;
const sLCD_FOURTH_ROW        = 212;
const sLCD_CLEAR             =   1;
const sLCD_RETURN_HOME       =   2;
const sLCD_CURSOR_OFF        =  12;
const sLCD_UNDERLINE_ON      =  14;
const sLCD_BLINK_CURSOR_ON   =  15;
const sLCD_MOVE_CURSOR_LEFT  =  16;
const sLCD_MOVE_CURSOR_RIGHT =  20;
const sLCD_TURN_OFF          =   0;
const sLCD_TURN_ON           =   8;
const sLCD_SHIFT_LEFT        =  24;
const sLCD_SHIFT_RIGHT       =  28;
//**************************************************************************
//**************************************************************************
void Nybble(unsigned char LCDOut, unsigned char RS)
// Strobes in Clk and Data lines for 74174 D Flip-Flop
{
unsigned char i;
    Data = 0;
    for (i = 0; i < 6; i++)     	//  Clear Shift Register
    {
        Clk = 1;                	//  Strobe
        Delay5us();
        Clk = 0;
    }
    LCDOut = LCDOut | (1 << 5) | ((RS & 1) * (1 << 4));
    for (i = 0; i < 6; i++)
    {
        if (0 != (LCDOut & (1 << 5)))
            Data = 1;
        else
	        Data = 0;
	        LCDOut = LCDOut << 1;
        Clk = 1;
        Delay5us();
        Clk = 0;
    }
    Data = 1;
    Data = 1;
    Data = 0;
    Data = 0;

} //  End NybbleShift
//**************************************************************************
//**************************************************************************
void sLCDWrite(unsigned char LCDData, unsigned char RSValue)
// Breaks Byte into 2 nybbles and writes to LCD
{
    Nybble((LCDData >> 4) & 0x0F, RSValue);
    Nybble(LCDData & 0x0F, RSValue);
    if ((0 == (LCDData & 0xFC)) && (0 == RSValue))
        Delay20us();
    else
        Delay20us();
} //  End LCDWrite
//**************************************************************************
//**************************************************************************
void sLCD_Chr(unsigned char row, unsigned char col, unsigned char character)
// Prints character at row and column
{
     sLCDWrite((row + (col - 1)), 0);
     sLCDWrite(character, 1);
} // End sLCD_Chr
//**************************************************************************
//**************************************************************************
void sLCD_Chr_Cp(unsigned char character)
// Prints character at current cursor position
{
     sLCDWrite(character, 1);
} // End sLCD_Chr_Cp
//**************************************************************************
//**************************************************************************
void sLCD_Cmd(unsigned char instruction)
// Prints various cursor commands  See sLCD_Consts.pbas for commands
{
     sLCDWrite (instruction, 0);
} // End sLCD_Cmd
//**************************************************************************
//**************************************************************************
void sMove_Cursor(unsigned char row, unsigned char col)
// Moves cursor to new cursor position
{
     sLCDWrite((row + (col - 1)), 0);
} // End Move Cursor
//**************************************************************************
//**************************************************************************
int NumtoChar(unsigned char val)		// Converts digital value to BCD Numbers
{									// (0 - 9)
   unsigned char ch;
   if (val < 10)
   {
     ch = val + '0';
   }
   else
   {
     val = val - 10;
     ch = val + 'A';
   }
   return(ch);
} // End NumtoChar
//**************************************************************************
//**************************************************************************
void sResetLCD()
// Clears LCD Display,  etc.
{
		sLCDWrite(0b00000001, 0);    //  Clear LCD and Home Cursor
    Delay5ms();
 		sLCDWrite(0b00000110, 0);    //  Move Cursor After Each Character
    Delay5ms();
		sLCDWrite(0b00001100, 0);    //  Turn On LCD and Enable Cursor
    Delay5ms();
} // End ResetLCD
//**************************************************************************
//**************************************************************************
void sLCD_Out(unsigned char row, unsigned char col, const char s[])
//Dstring displays Messages from Main Routine
//Works with 2x16 Character LCD
//Substitutes Message_x into const char s[]
{
	int i;
	sLCDWrite(row + (col - 1), 0);
	for (i = 0; s[i] != 0; i++)		  // 	Display String Message
	{
    sLCDWrite(s[i], 1);
	}
}
//**************************************************************************
void sLCD_Outn(unsigned char row, unsigned char col, char *s)
//Dstring displays Messages from Main Routine
//Works with 2x16 Character LCD
//Substitutes Message_x into const char s[]
{
	int i;
	sLCDWrite(row + (col - 1), 0);
	for (i = 0; s[i] != 0; i++)		  // 	Display String Message
	{
    sLCDWrite(s[i], 1);
	}
} // End sLCD_Outn

//**************************************************************************
//**************************************************************************
void sLCD_Out_Cp(const char s[])
//Dstring displays Messages from Main Routine
//Works with 2x16 Character LCD
//Substitutes Message_x into const char s[]
{
	int i;
//	sLCDWrite(row + (col - 1), 0);
	for (i = 0; s[i] != 0; i++)		  // 	Display String Message
	{
    sLCDWrite(s[i], 1);
	}
} // End DString
//**************************************************************************
//**************************************************************************
void sLCDtoBCD(long int val, unsigned char digits)
// displays byte in decimal as either 1, 2 , 3, 4, or 5 digits
{
  int d;
  unsigned char ch;

   if (digits == 5)					// Take 10000's Digits
      {
     	d = val/10000;				// Divide it by 10000
     	ch = NumtoChar(d);		// Take that number and convert it to ASCII
		  sLCDWrite(ch, 1);			// Send that value to display
	    }
   if (digits > 3)					// Take 1000's Digits
	    {
		  val = val%10000;
     	d = val/1000;					// Divide it by 1000
     	ch = NumtoChar(d);		// Take that number and convert it to ASCII
		  sLCDWrite(ch, 1);			// Send that value to display
	    }
   if (digits > 2)					// Take 100's Digits
	    {
		  val = val%1000;
     	d = val/100;					// Divide it by 100
     	ch = NumtoChar(d);		// Take that number and convert it to ASCII
		  sLCDWrite(ch, 1);			// Send that value to display
      }
   if (digits > 1)					// Take the two lowest digits
      {
      val = val%100;
      d = val/10;					  // Divide it by 10
      ch = NumtoChar(d);    // Take that number and convert it to ASCII
	 	  sLCDWrite(ch, 1);			// Send that value to display
      }
   if (digits == 1)					// Take the least significant digit
      {
      val = val%100;
      }
      	d = val % 10;				// Take the Modulus of val
   	  	ch = NumtoChar(d);  // Take that number and convert it to ASCII
 		    sLCDWrite(ch, 1);		// Send that value to display
} // End LCDtoBCD
//**************************************************************************
//**************************************************************************
// Initialize Serial LCD Display
//**************************************************************************
void Init_sDisplay()
{
char i;
  for (i = 0; i < 3; i++)
      {
      Delay5ms();
    	Nybble(3, 0);          	//  Init LCD
    	}
    	Nybble(2, 0);          	//  Set LCD 4 Bit Mode
      Delay5ms();
}
//**************************************************************************